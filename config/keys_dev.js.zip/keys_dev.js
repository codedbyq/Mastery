// keys_dev.js
module.exports = {
  mongoURI: 'mongodb+srv://dev:C20JVsD7DVvSg6eh@cluster0.bxg18.mongodb.net/test?retryWrites=true&w=majority',
  secretOrKey: 'j2rl8HAN32',
  AWS_BUCKET_NAME: 'mastery',
  AWS_ACCESS_KEY_ID: 'AKIAIWLCO6B7XFO5MYPQ',
  AWS_SECRET_ACCESS_KEY: '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',
  AWS_REGION: 'us-west-1',
  AWS_Uploaded_File_URL_LINK: 'https://s3-us-west-1.amazonaws.com/mastery'
}
